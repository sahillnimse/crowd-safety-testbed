"""
Shared RT-DETRv2 box detector.

One detector, used by every wrapper that needs person or vehicle boxes as an
input to its own work — the violence models' person-ROI crop, MediaPipe's
person stage, ANPR's vehicle capture, and the dense-flow validation route.

Why one shared module
---------------------
Each of those wrappers used to construct its own YOLO instance from its own
hard-coded checkpoint name.  That put the same responsibility in five places
with five slightly different confidence defaults and class filters, and it
meant swapping the backbone touched every one of them.  The detector is a
dependency of those models, not part of what they are.

Why RT-DETRv2 rather than YOLO
------------------------------
Apache 2.0 licensed (``PekingU/rtdetr_v2_r18vd``), and unlike YOLO's
AGPL-3.0 it carries no copyleft obligation on the surrounding code — which
matters for anything deployed rather than demonstrated.  It is also already
the backbone of the traffic, ANPR and umbrella detectors in this project, so
the number of distinct architectures to reason about goes down.

What it cannot do
-----------------
Keypoints.  RT-DETRv2 is a detection model: it returns boxes, not skeletons.
Any wrapper needing pose has to use a pose model (MediaPipe, MoveNet) — it
cannot be served from here.  This is why the skeleton-based fall models,
which depended on YOLO-pose, were removed rather than ported.
"""

from __future__ import annotations

import logging
import threading
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# Apache 2.0, COCO-pretrained.  Downloaded and cached by transformers on
# first use.
DEFAULT_CHECKPOINT = "PekingU/rtdetr_v2_r18vd"

# COCO class indices used across the project.
COCO_PERSON = 0
COCO_VEHICLES = (2, 3, 5, 7)          # car, motorcycle, bus, truck
COCO_UMBRELLA = 25

# One instance per (checkpoint, device).  These wrappers are constructed per
# job and several may run in the same process; loading a separate copy of the
# same weights for each would multiply GPU memory for no benefit.
_CACHE: dict[tuple[str, str], "BoxDetector"] = {}
_CACHE_LOCK = threading.Lock()


class BoxDetector:
    """
    RT-DETRv2 object detector returning plain [x1, y1, x2, y2] boxes.

    Thread-safety: inference is guarded by an internal lock, so one instance
    may be shared between the job worker and the validation runner.
    """

    def __init__(
        self,
        checkpoint: str = DEFAULT_CHECKPOINT,
        device: Optional[str] = None,
        conf_threshold: float = 0.35,
    ) -> None:
        self.checkpoint = checkpoint
        self.device = device or "cpu"
        self.conf_threshold = conf_threshold
        self._proc = None
        self._model = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------

    def load(self) -> None:
        if self._model is not None:
            return
        import torch
        from transformers import RTDetrImageProcessor, RTDetrV2ForObjectDetection

        logger.info("Loading RT-DETRv2 detector (%s) on %s ...",
                    self.checkpoint, self.device)
        self._proc = RTDetrImageProcessor.from_pretrained(self.checkpoint)
        model = RTDetrV2ForObjectDetection.from_pretrained(self.checkpoint)
        self._model = model.to(self.device).eval()
        self._torch = torch

    def detect(
        self,
        frame: np.ndarray,
        classes: Optional[tuple[int, ...]] = None,
        conf_threshold: Optional[float] = None,
    ) -> list[list[float]]:
        """
        Detect objects in a BGR frame.

        classes: COCO indices to keep, or None for everything.
        Returns [[x1, y1, x2, y2], ...] in source pixel coordinates.
        """
        self.load()
        from PIL import Image

        h, w = frame.shape[:2]
        conf = self.conf_threshold if conf_threshold is None else conf_threshold

        with self._lock:
            inputs = self._proc(images=Image.fromarray(frame[:, :, ::-1]),
                                return_tensors="pt")
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            with self._torch.no_grad():
                outputs = self._model(**inputs)
            target = self._torch.tensor([[h, w]], device=self.device)
            results = self._proc.post_process_object_detection(
                outputs, threshold=conf, target_sizes=target)[0]

        keep = set(classes) if classes else None
        boxes: list[list[float]] = []
        for box, label in zip(results["boxes"].cpu().tolist(),
                              results["labels"].cpu().tolist()):
            if keep is None or int(label) in keep:
                boxes.append([float(v) for v in box])
        return boxes

    def detect_with_labels(
        self,
        frame: np.ndarray,
        classes: Optional[tuple[int, ...]] = None,
        conf_threshold: Optional[float] = None,
    ) -> list[tuple[list[float], int, float]]:
        """As detect(), but returns (box, class_index, score) per detection."""
        self.load()
        from PIL import Image

        h, w = frame.shape[:2]
        conf = self.conf_threshold if conf_threshold is None else conf_threshold

        with self._lock:
            inputs = self._proc(images=Image.fromarray(frame[:, :, ::-1]),
                                return_tensors="pt")
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            with self._torch.no_grad():
                outputs = self._model(**inputs)
            target = self._torch.tensor([[h, w]], device=self.device)
            results = self._proc.post_process_object_detection(
                outputs, threshold=conf, target_sizes=target)[0]

        keep = set(classes) if classes else None
        out: list[tuple[list[float], int, float]] = []
        for box, label, score in zip(results["boxes"].cpu().tolist(),
                                     results["labels"].cpu().tolist(),
                                     results["scores"].cpu().tolist()):
            if keep is None or int(label) in keep:
                out.append(([float(v) for v in box], int(label), float(score)))
        return out

    @property
    def id2label(self) -> dict:
        self.load()
        return {int(k): v for k, v in self._model.config.id2label.items()}


def get_detector(
    device: Optional[str] = None,
    conf_threshold: float = 0.35,
    checkpoint: str = DEFAULT_CHECKPOINT,
) -> BoxDetector:
    """
    Shared detector for (checkpoint, device).

    Prefer this over constructing BoxDetector directly: several wrappers can
    be active at once, and each holding its own copy of the same weights is
    the quickest way to exhaust a small card.
    """
    key = (checkpoint, device or "cpu")
    with _CACHE_LOCK:
        det = _CACHE.get(key)
        if det is None:
            det = BoxDetector(checkpoint=checkpoint, device=device,
                              conf_threshold=conf_threshold)
            _CACHE[key] = det
    return det
